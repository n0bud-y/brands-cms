import type { CSSProperties } from 'react'
import { Head, useForm } from '@inertiajs/react'
import { cx } from '@/lib/utils'
import { Button, Field, Input } from '@/components/ui'

const STICKERS = [
  { text: '⚡ instant publish', className: 'bg-pop-lime text-ink top-[18%] right-[10%]', tilt: '6deg', delay: '0s' },
  { text: '🔍 SEO-ready', className: 'bg-pop-yellow text-ink top-[44%] right-[22%]', tilt: '-5deg', delay: '-2s' },
  { text: '🎨 every brand, one place', className: 'bg-pop-cyan text-ink bottom-[30%] right-[8%]', tilt: '3deg', delay: '-4s' },
]

export default function Login() {
  const form = useForm({ email: '', password: '' })

  return (
    <main className="grid min-h-screen lg:grid-cols-[1.1fr_1fr]">
      <Head title="Sign in" />
      <section className="relative hidden flex-col justify-between overflow-hidden border-r-2 border-ink bg-pop-violet p-12 text-white lg:flex">
        {/* Decorative shapes */}
        <div className="absolute -top-24 -right-24 size-80 rounded-full border-2 border-ink bg-pop-pink" />
        <div className="absolute -right-20 -bottom-24 size-72 rotate-12 rounded-[3rem] border-2 border-ink bg-pop-yellow" />
        <div className="absolute top-[14%] left-[46%] size-12 rotate-45 border-2 border-ink bg-pop-lime" />

        <div className="relative flex items-center gap-2.5 text-xl font-extrabold">
          <span className="grid size-10 -rotate-6 place-items-center rounded-xl border-2 border-ink bg-pop-lime text-ink">✦</span>
          <span>
            brand<span className="text-pop-lime">.</span>cms
          </span>
        </div>

        <h1 className="relative text-6xl leading-[0.95] font-extrabold tracking-tight xl:text-7xl">
          one panel.
          <br />
          <span className="my-2 inline-block -rotate-2 rounded-2xl border-2 border-ink bg-pop-lime px-3 text-ink shadow-hard">
            every
          </span>{' '}
          brand.
          <br />
          zero chaos.
        </h1>

        {STICKERS.map((s) => (
          <span
            key={s.text}
            style={{ '--tilt': s.tilt, animationDelay: s.delay } as CSSProperties}
            className={cx('absolute animate-float rounded-full border-2 border-ink px-4 py-2 text-sm font-bold shadow-hard', s.className)}
          >
            {s.text}
          </span>
        ))}

        <p className="relative max-w-sm text-sm text-white/80">
          Blogs and settings for all your publishing &amp; design brands, live on every site in seconds.
        </p>
      </section>

      <section className="grid place-items-center px-4 py-12">
        <form
          className="w-full max-w-sm animate-pop-in space-y-5 rounded-3xl border-2 border-ink bg-white p-7 shadow-hard-lg"
          onSubmit={(e) => {
            e.preventDefault()
            form.post('/login', { onFinish: () => form.reset('password') })
          }}
        >
          <div>
            <span className="mb-4 inline-grid size-12 place-items-center rounded-2xl border-2 border-ink bg-pop-yellow text-2xl shadow-hard-sm">
              👋
            </span>
            <h2 className="text-3xl font-extrabold tracking-tight">Welcome back</h2>
            <p className="text-sm text-ink/60">Sign in to run your brands.</p>
          </div>
          <Field label="Email" error={form.errors.email}>
            <Input
              type="email"
              autoComplete="username"
              required
              autoFocus
              placeholder="you@agency.com"
              value={form.data.email}
              onChange={(e) => form.setData('email', e.target.value)}
            />
          </Field>
          <Field label="Password" error={form.errors.password}>
            <Input
              type="password"
              autoComplete="current-password"
              required
              placeholder="••••••••"
              value={form.data.password}
              onChange={(e) => form.setData('password', e.target.value)}
            />
          </Field>
          <Button type="submit" variant="pop" size="lg" className="w-full" disabled={form.processing}>
            {form.processing ? 'Signing in…' : "Let's go →"}
          </Button>
        </form>
      </section>
    </main>
  )
}
