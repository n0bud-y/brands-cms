<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Post;
use App\Models\Site;
use Illuminate\Http\Request;

/** Read-only API the brand sites call (server-side, via cms/brand.php). Published content only. */
class BrandApiController extends Controller
{
    private const SUMMARY = ['id', 'title', 'slug', 'layout', 'cover_image', 'excerpt', 'published_at', 'updated_at'];

    public function settings(Site $site)
    {
        return [
            'name' => $site->name,
            'url' => $site->url,
            'settings' => (object) $site->settings()->pluck('value', 'key')->all(),
        ];
    }

    public function posts(Request $request, Site $site)
    {
        $perPage = min(max((int) $request->query('per_page', 10), 1), 50);
        $posts = $site->posts()->published()->latest('published_at')->select(self::SUMMARY)->paginate($perPage);

        return [
            'data' => $posts->getCollection()->map(fn (Post $post) => $this->summary($post)),
            'meta' => [
                'current_page' => $posts->currentPage(),
                'last_page' => $posts->lastPage(),
                'per_page' => $posts->perPage(),
                'total' => $posts->total(),
            ],
        ];
    }

    public function post(Site $site, string $slug)
    {
        $post = $site->posts()->published()->where('slug', $slug)->first();
        if ($post) {
            return $this->summary($post) + [
                'blocks' => $post->blocks ?? [],
                'meta_title' => $post->meta_title ?: $post->title,
                'meta_description' => $post->meta_description ?: (string) $post->excerpt,
                'og_image' => $post->og_image ?: $post->cover_image,
                'schema' => $post->schema,
            ];
        }

        // Renamed post: tell the brand site where it lives now so it can 301.
        $redirect = $site->redirects()->where('old_slug', $slug)->value('post_id');
        $target = $redirect ? $site->posts()->published()->whereKey($redirect)->value('slug') : null;
        if ($target) {
            return response()->json(['redirect' => $target], 301);
        }

        return response()->json(['message' => 'Not found.'], 404);
    }

    public function sitemap(Site $site)
    {
        return [
            'data' => $site->posts()->published()->latest('published_at')->limit(50000)->get(['slug', 'updated_at'])
                ->map(fn (Post $post) => ['slug' => $post->slug, 'updated_at' => $post->updated_at->toAtomString()]),
        ];
    }

    private function summary(Post $post): array
    {
        return [
            'title' => $post->title,
            'slug' => $post->slug,
            'layout' => $post->layout,
            'cover_image' => $post->cover_image,
            'excerpt' => $post->excerpt,
            'published_at' => $post->published_at?->toAtomString(),
            'updated_at' => $post->updated_at?->toAtomString(),
        ];
    }
}
