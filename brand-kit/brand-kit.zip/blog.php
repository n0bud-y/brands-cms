<?php
// Blog listing at /blogs (see htaccess-rules.txt).

require __DIR__ . '/cms/brand.php';

$page = max(1, (int) ($_GET['page'] ?? 1));
$result = cms_posts($page);
if ($result === null) {
    cms_unavailable();
}

$posts = $result['data'];
$lastPage = (int) $result['meta']['last_page'];
if ($page > 1 && $page > $lastPage) {
    cms_not_found();
}

$title = setting_raw('blog_title', 'Blog');
$pageUrl = function ($n) {
    return cms_url('/blogs' . ($n > 1 ? '?page=' . $n : ''));
};

cms_header([
    'title' => $page > 1 ? "{$title} – Page {$page}" : $title,
    'description' => setting_raw('blog_description'),
    'url' => $pageUrl($page),
    'prev' => $page > 1 ? $pageUrl($page - 1) : null,
    'next' => $page < $lastPage ? $pageUrl($page + 1) : null,
]);
?>
<div class="container py-5">
    <header class="mb-5">
        <h1 class="display-6 fw-bold"><?= cms_e($title) ?></h1>
        <?php if (setting_raw('blog_description') !== ''): ?>
            <p class="lead text-muted mb-0"><?= setting('blog_description') ?></p>
        <?php endif ?>
    </header>

    <?php if (!$posts): ?>
        <p class="text-muted">No posts yet. Check back soon.</p>
    <?php else: ?>
        <div class="row g-4">
            <?php foreach ($posts as $post): ?>
                <div class="col-md-6 col-lg-4">
                    <article class="card h-100 border-0 shadow-sm">
                        <?php if ($post['cover_image']): ?>
                            <img src="<?= cms_e($post['cover_image']) ?>" class="card-img-top cms-card-img" alt="" loading="lazy" decoding="async">
                        <?php endif ?>
                        <div class="card-body">
                            <p class="small text-muted mb-2">
                                <time datetime="<?= cms_e($post['published_at']) ?>"><?= cms_e(cms_date($post['published_at'])) ?></time>
                            </p>
                            <h2 class="h5 card-title">
                                <a href="/blogs/<?= cms_e($post['slug']) ?>" class="stretched-link text-reset text-decoration-none"><?= cms_e($post['title']) ?></a>
                            </h2>
                            <?php if ($post['excerpt']): ?>
                                <p class="card-text text-muted"><?= cms_e($post['excerpt']) ?></p>
                            <?php endif ?>
                        </div>
                    </article>
                </div>
            <?php endforeach ?>
        </div>

        <?php if ($lastPage > 1): ?>
            <nav class="mt-5" aria-label="Blog pages">
                <ul class="pagination justify-content-center">
                    <?php for ($n = 1; $n <= $lastPage; $n++): ?>
                        <li class="page-item <?= $n === $page ? 'active' : '' ?>">
                            <a class="page-link" href="<?= $n > 1 ? '/blogs?page=' . $n : '/blogs' ?>"><?= $n ?></a>
                        </li>
                    <?php endfor ?>
                </ul>
            </nav>
        <?php endif ?>
    <?php endif ?>
</div>
<?php cms_footer();
