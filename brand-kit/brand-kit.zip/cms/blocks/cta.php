<?php
/** @var array $block  title, text, button, url */
if (($block['title'] ?? '') === '' && ($block['button'] ?? '') === '') {
    return;
}
?>
<aside class="bg-light rounded-3 p-4 p-md-5 my-5 text-center">
    <?php if (($block['title'] ?? '') !== ''): ?>
        <h2 class="h3 fw-bold"><?= cms_e($block['title']) ?></h2>
    <?php endif ?>
    <?php if (($block['text'] ?? '') !== ''): ?>
        <p class="text-muted mb-4"><?= nl2br(cms_e($block['text'])) ?></p>
    <?php endif ?>
    <?php if (($block['button'] ?? '') !== '' && ($block['url'] ?? '') !== ''): ?>
        <a class="btn btn-primary btn-lg" href="<?= cms_e($block['url']) ?>"><?= cms_e($block['button']) ?></a>
    <?php endif ?>
</aside>
