<?php
/** @var array $block  images: [{url, alt}] */
if (empty($block['images'])) {
    return;
}
?>
<div class="row g-3 my-5 cms-gallery">
    <?php foreach ($block['images'] as $image): ?>
        <div class="col-6 col-md-4">
            <a href="<?= cms_e($image['url']) ?>" target="_blank" rel="noopener">
                <img src="<?= cms_e($image['url']) ?>" alt="<?= cms_e($image['alt'] ?? '') ?>" class="img-fluid rounded w-100" loading="lazy" decoding="async">
            </a>
        </div>
    <?php endforeach ?>
</div>
