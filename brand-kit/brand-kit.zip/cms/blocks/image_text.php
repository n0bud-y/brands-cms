<?php
/** @var array $block  image, alt, html (sanitized by the panel), side (left|right) */
if (($block['image'] ?? '') === '' && ($block['html'] ?? '') === '') {
    return;
}
?>
<div class="row align-items-center g-4 my-5 <?= ($block['side'] ?? 'left') === 'right' ? 'flex-md-row-reverse' : '' ?>">
    <?php if (($block['image'] ?? '') !== ''): ?>
        <div class="col-md-6">
            <img src="<?= cms_e($block['image']) ?>" alt="<?= cms_e($block['alt'] ?? '') ?>" class="img-fluid rounded" loading="lazy" decoding="async">
        </div>
    <?php endif ?>
    <div class="col-md-6 cms-prose"><?= $block['html'] ?? '' ?></div>
</div>
