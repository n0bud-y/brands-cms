<?php
/** @var array $block  text, level (2|3), anchor */
if (($block['text'] ?? '') === '') {
    return;
}
$tag = (int) ($block['level'] ?? 2) === 3 ? 'h3' : 'h2';
?>
<<?= $tag ?> <?= $block['anchor'] ? 'id="' . cms_e($block['anchor']) . '"' : '' ?> class="fw-bold <?= $tag === 'h2' ? 'h3 mt-5 mb-3' : 'h5 mt-4 mb-2' ?>"><?= cms_e($block['text']) ?></<?= $tag ?>>
