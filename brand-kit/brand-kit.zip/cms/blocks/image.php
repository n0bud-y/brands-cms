<?php
/** @var array $block  url, alt, caption */
if (($block['url'] ?? '') === '') {
    return;
}
?>
<figure class="my-5">
    <img src="<?= cms_e($block['url']) ?>" alt="<?= cms_e($block['alt'] ?? '') ?>" class="img-fluid rounded w-100" loading="lazy" decoding="async">
    <?php if (($block['caption'] ?? '') !== ''): ?>
        <figcaption class="small text-muted text-center mt-2"><?= cms_e($block['caption']) ?></figcaption>
    <?php endif ?>
</figure>
