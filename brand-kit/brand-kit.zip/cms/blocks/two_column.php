<?php
/** @var array $block  left, right (html, sanitized by the panel) */
?>
<div class="row g-4 my-4">
    <div class="col-md-6 cms-prose"><?= $block['left'] ?? '' ?></div>
    <div class="col-md-6 cms-prose"><?= $block['right'] ?? '' ?></div>
</div>
