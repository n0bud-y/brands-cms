<?php
/** @var array $block  text, cite */
if (($block['text'] ?? '') === '') {
    return;
}
?>
<figure class="cms-quote my-5">
    <blockquote class="mb-2"><p class="mb-0"><?= nl2br(cms_e($block['text'])) ?></p></blockquote>
    <?php if (($block['cite'] ?? '') !== ''): ?>
        <figcaption class="text-muted">— <?= cms_e($block['cite']) ?></figcaption>
    <?php endif ?>
</figure>
