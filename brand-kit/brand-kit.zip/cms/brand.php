<?php
/**
 * Brand CMS client: loads this website's settings and blog posts from the central panel.
 *
 *   require __DIR__ . '/cms/brand.php';
 *   <a href="tel:<?= cms_tel(setting_raw('phone')) ?>"><?= setting('phone') ?></a>
 *
 * API responses are cached as JSON files in cms/cache/. When the panel is unreachable the
 * last cached copy keeps being served, so the website never breaks because of the panel.
 * The panel clears this cache via cms/clear-cache.php whenever content changes.
 *
 * Compatible with PHP 7.4+. Needs either the curl extension or allow_url_fopen.
 */

if (defined('BRAND_CMS')) {
    return;
}
define('BRAND_CMS', __DIR__);

const CMS_BLOCK_TYPES = ['heading', 'paragraph', 'image', 'image_text', 'quote', 'cta', 'two_column', 'gallery', 'faq'];

function cms_config($key = null)
{
    static $config = null;

    if ($config === null) {
        $file = __DIR__ . '/config.php';
        if (!is_file($file)) {
            trigger_error('Brand CMS: copy cms/config.example.php to cms/config.php and fill it in.', E_USER_WARNING);
        }
        $config = (is_file($file) ? (array) require $file : []) + [
            'panel_url' => '',
            'site' => '',
            'api_key' => '',
            'cache_secret' => '',
            'site_url' => '',
            'cache_ttl' => 600,
            'timeout' => 3,
            'posts_per_page' => 9,
            'kit_url' => '/cms',
            'cache_dir' => __DIR__ . '/cache',
            'header' => __DIR__ . '/partials/header.php',
            'footer' => __DIR__ . '/partials/footer.php',
            'error_page' => __DIR__ . '/partials/error.php',
        ];
    }

    return $key === null ? $config : ($config[$key] ?? null);
}

/** Escape for HTML text and attributes. */
function cms_e($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/* -------------------------------------------------------------------------
 * API + cache
 * ---------------------------------------------------------------------- */

/**
 * GET a panel API path through the file cache.
 * Returns ['status' => 200|301|404, 'body' => array|null], or null when the panel
 * is unreachable and nothing is cached yet.
 */
function cms_api($path)
{
    static $memo = [];
    if (array_key_exists($path, $memo)) {
        return $memo[$path];
    }

    $file = cms_cache_file($path);
    $cached = is_file($file) ? json_decode((string) @file_get_contents($file), true) : null;
    if (is_array($cached) && time() < ($cached['expires'] ?? 0)) {
        return $memo[$path] = $cached;
    }

    $fresh = cms_http($path);
    if ($fresh === null) {
        // Panel down or erroring: keep serving the stale copy and retry in a minute.
        if (is_array($cached)) {
            $cached['expires'] = time() + 60;
            cms_cache_write($file, $cached);
        }

        return $memo[$path] = is_array($cached) ? $cached : null;
    }

    // Misses are cached briefly so bots probing random URLs don't each reach the panel.
    $fresh['expires'] = time() + ($fresh['status'] === 200 ? (int) cms_config('cache_ttl') : 60);
    cms_cache_write($file, $fresh);

    return $memo[$path] = $fresh;
}

function cms_http($path)
{
    $url = rtrim((string) cms_config('panel_url'), '/') . '/api/v1/' . rawurlencode((string) cms_config('site')) . $path;
    $headers = ['Accept: application/json', 'X-Api-Key: ' . cms_config('api_key')];
    $timeout = max(1, (int) cms_config('timeout'));

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_CONNECTTIMEOUT => $timeout,
            CURLOPT_TIMEOUT => $timeout + 2,
            CURLOPT_FOLLOWLOCATION => false,
        ]);
        $body = curl_exec($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    } else {
        $context = stream_context_create(['http' => [
            'header' => implode("\r\n", $headers),
            'timeout' => $timeout + 2,
            'ignore_errors' => true,
            'follow_location' => 0,
        ]]);
        $body = @file_get_contents($url, false, $context);
        $responseHeaders = function_exists('http_get_last_response_headers')
            ? (array) http_get_last_response_headers()
            : ($http_response_header ?? []);
        $status = isset($responseHeaders[0]) && preg_match('/\s(\d{3})/', $responseHeaders[0], $m) ? (int) $m[1] : 0;
    }

    if (!is_string($body) || !in_array($status, [200, 301, 404], true)) {
        return null;
    }

    $data = json_decode($body, true);
    if ($status === 200 && !is_array($data)) {
        return null;
    }

    return ['status' => $status, 'body' => is_array($data) ? $data : null];
}

function cms_cache_file($path)
{
    return rtrim((string) cms_config('cache_dir'), '/\\') . '/' . sha1(cms_config('site') . '|' . $path) . '.json';
}

function cms_cache_write($file, array $data)
{
    $dir = dirname($file);
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }

    // Write then rename, so a reader never sees a half-written file.
    $tmp = $file . '.' . uniqid('', true) . '.tmp';
    if (@file_put_contents($tmp, json_encode($data), LOCK_EX) !== false) {
        @rename($tmp, $file);
    }
}

/** Deletes every cached response. Returns how many files were removed. */
function cms_clear_cache()
{
    $count = 0;
    foreach (glob(rtrim((string) cms_config('cache_dir'), '/\\') . '/*.json') ?: [] as $file) {
        $count += @unlink($file) ? 1 : 0;
    }

    return $count;
}

/* -------------------------------------------------------------------------
 * Settings
 * ---------------------------------------------------------------------- */

function cms_settings()
{
    $res = cms_api('/settings');

    return ($res['status'] ?? 0) === 200 ? (array) ($res['body']['settings'] ?? []) : [];
}

function cms_site_name()
{
    $res = cms_api('/settings');

    return (string) ($res['body']['name'] ?? '');
}

if (!function_exists('setting_raw')) {
    /** A setting's raw value (not escaped). Use for building URLs or with your own escaping. */
    function setting_raw($key, $default = '')
    {
        $settings = cms_settings();

        return isset($settings[$key]) && $settings[$key] !== '' ? (string) $settings[$key] : (string) $default;
    }
}

if (!function_exists('setting')) {
    /** A setting's value, HTML-escaped and safe to echo anywhere in a page. */
    function setting($key, $default = '')
    {
        return cms_e(setting_raw($key, $default));
    }
}

/** "+1 555 0100" -> "+15550100", for tel: links. */
function cms_tel($number)
{
    return (string) preg_replace('/[^0-9+]/', '', (string) $number);
}

function cms_whatsapp_url($number, $text = '')
{
    return 'https://wa.me/' . preg_replace('/\D/', '', (string) $number) . ($text !== '' ? '?text=' . rawurlencode($text) : '');
}

/* -------------------------------------------------------------------------
 * Posts
 * ---------------------------------------------------------------------- */

function cms_valid_slug($slug)
{
    return is_string($slug) && strlen($slug) <= 190 && preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/', $slug) === 1;
}

/** One page of published posts: ['data' => [...], 'meta' => [...]], or null if the panel is unavailable. */
function cms_posts($page = 1)
{
    $res = cms_api('/posts?' . http_build_query([
        'page' => max(1, (int) $page),
        'per_page' => (int) cms_config('posts_per_page'),
    ]));

    return ($res['status'] ?? 0) === 200 ? $res['body'] : null;
}

/**
 * Looks up a published post. Returns one of:
 *   ['status' => 200, 'post' => [...]]
 *   ['status' => 301, 'redirect' => 'new-slug']   (the post was renamed)
 *   ['status' => 404]
 *   ['status' => 503]                              (panel unreachable, nothing cached)
 */
function cms_post($slug)
{
    if (!cms_valid_slug($slug)) {
        return ['status' => 404];
    }

    $res = cms_api('/posts/' . $slug);
    if ($res === null) {
        return ['status' => 503];
    }
    if ($res['status'] === 200) {
        return ['status' => 200, 'post' => $res['body']];
    }
    if ($res['status'] === 301 && cms_valid_slug($res['body']['redirect'] ?? null)) {
        return ['status' => 301, 'redirect' => $res['body']['redirect']];
    }

    return ['status' => 404];
}

function cms_sitemap_posts()
{
    $res = cms_api('/sitemap');

    return ($res['status'] ?? 0) === 200 ? (array) ($res['body']['data'] ?? []) : [];
}

/* -------------------------------------------------------------------------
 * URLs + formatting
 * ---------------------------------------------------------------------- */

function cms_url($path = '')
{
    return rtrim((string) cms_config('site_url'), '/') . $path;
}

function cms_post_url($slug)
{
    return cms_url('/blogs/' . $slug);
}

function cms_asset($file)
{
    return rtrim((string) cms_config('kit_url'), '/') . '/assets/' . $file;
}

function cms_date($iso, $format = 'F j, Y')
{
    $time = $iso ? strtotime((string) $iso) : false;

    return $time ? date($format, $time) : '';
}

/* -------------------------------------------------------------------------
 * Rendering
 * ---------------------------------------------------------------------- */

/**
 * Prints the page header. $meta keys: title, description, image, url (canonical),
 * type (website|article), robots, prev, next, jsonld (generated schema), schema (the post's custom schema).
 */
function cms_header(array $meta = [])
{
    $meta += [
        'title' => cms_site_name(),
        'description' => '',
        'image' => '',
        'url' => cms_url(strtok((string) ($_SERVER['REQUEST_URI'] ?? '/'), '?')),
        'type' => 'website',
        'robots' => '',
        'prev' => null,
        'next' => null,
        'jsonld' => null,
        'schema' => null,
    ];
    include cms_config('header');
}

function cms_footer()
{
    include cms_config('footer');
}

function cms_error_page($status, $title, $message)
{
    http_response_code($status);
    if ($status === 503) {
        header('Retry-After: 300');
    }
    include cms_config('error_page');
    exit;
}

function cms_not_found()
{
    cms_error_page(404, 'Page not found', 'The page you are looking for does not exist or has moved.');
}

function cms_unavailable()
{
    cms_error_page(503, 'Temporarily unavailable', 'This page could not be loaded right now. Please try again in a few minutes.');
}

/** The brand-wide JSON-LD from the dashboard's Settings page, or null. */
function cms_brand_schema()
{
    $data = json_decode(setting_raw('schema'), true);

    return is_array($data) ? $data : null;
}

/** Every JSON-LD block for a page: generated, the post's custom schema, and the brand-wide one. */
function cms_schema_tags(array $meta)
{
    $html = '';
    foreach ([$meta['jsonld'] ?? null, $meta['schema'] ?? null, cms_brand_schema()] as $data) {
        if (is_array($data) && $data) {
            $html .= cms_json_ld($data) . "\n";
        }
    }

    return $html;
}

/** Re-encodes JSON-LD into a script tag. JSON_HEX_TAG stops "</script>" in the data from breaking out. */
function cms_json_ld(array $data)
{
    return '<script type="application/ld+json">'
        . json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP)
        . '</script>';
}

/** Stable id="" anchors for heading blocks (block index => anchor), shared by headings and tables of contents. */
function cms_heading_anchors($blocks)
{
    $anchors = [];
    $seen = [];
    foreach ((array) $blocks as $i => $block) {
        if (($block['type'] ?? '') !== 'heading') {
            continue;
        }
        $base = trim((string) preg_replace('/[^a-z0-9]+/', '-', strtolower((string) ($block['text'] ?? ''))), '-');
        $base = $base !== '' ? $base : 'section';
        $seen[$base] = ($seen[$base] ?? 0) + 1;
        $anchors[$i] = $seen[$base] > 1 ? $base . '-' . $seen[$base] : $base;
    }

    return $anchors;
}

/** Renders each block with cms/blocks/{type}.php. Unknown types are skipped. */
function cms_render_blocks($blocks)
{
    $anchors = cms_heading_anchors($blocks);
    foreach ((array) $blocks as $i => $block) {
        $type = $block['type'] ?? '';
        if (in_array($type, CMS_BLOCK_TYPES, true) && is_file($file = __DIR__ . '/blocks/' . $type . '.php')) {
            $block['anchor'] = $anchors[$i] ?? '';
            cms_include_block($file, $block);
        }
    }
}

/** Includes a block template with only $block in scope. */
function cms_include_block($__file, array $block)
{
    include $__file;
}
