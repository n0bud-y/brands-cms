<?php
/** Sidebar: content left, table of contents + contact box right. @var array $post */

$toc = [];
foreach (cms_heading_anchors($post['blocks']) as $i => $anchor) {
    $toc[] = ['anchor' => $anchor, 'text' => $post['blocks'][$i]['text'], 'sub' => (int) $post['blocks'][$i]['level'] === 3];
}
$phone = setting_raw('phone');
$email = setting_raw('email');
$whatsapp = setting_raw('whatsapp');
?>
<div class="container py-5">
    <div class="row g-5">
        <article class="col-lg-8">
            <header class="mb-4">
                <p class="small text-muted mb-2">
                    <a href="/blogs" class="text-reset">Blog</a> ·
                    <time datetime="<?= cms_e($post['published_at']) ?>"><?= cms_e(cms_date($post['published_at'])) ?></time>
                </p>
                <h1 class="display-6 fw-bold"><?= cms_e($post['title']) ?></h1>
                <?php if ($post['excerpt']): ?>
                    <p class="lead text-muted"><?= cms_e($post['excerpt']) ?></p>
                <?php endif ?>
            </header>

            <?php if ($post['cover_image']): ?>
                <img src="<?= cms_e($post['cover_image']) ?>" alt="<?= cms_e($post['title']) ?>" class="img-fluid rounded w-100 mb-5" fetchpriority="high">
            <?php endif ?>

            <?php cms_render_blocks($post['blocks']) ?>
        </article>

        <aside class="col-lg-4">
            <div class="cms-sticky">
                <?php if ($toc): ?>
                    <nav class="p-4 bg-light rounded mb-4" aria-label="On this page">
                        <p class="fw-semibold mb-2">On this page</p>
                        <ul class="list-unstyled mb-0">
                            <?php foreach ($toc as $item): ?>
                                <li class="<?= $item['sub'] ? 'ps-3 small' : '' ?> py-1">
                                    <a href="#<?= cms_e($item['anchor']) ?>" class="text-reset"><?= cms_e($item['text']) ?></a>
                                </li>
                            <?php endforeach ?>
                        </ul>
                    </nav>
                <?php endif ?>

                <?php if ($phone !== '' || $email !== '' || $whatsapp !== ''): ?>
                    <div class="p-4 rounded border">
                        <p class="fw-semibold mb-1">Have a question?</p>
                        <p class="text-muted small">Our team is happy to help.</p>
                        <div class="d-grid gap-2">
                            <?php if ($phone !== ''): ?>
                                <a class="btn btn-primary" href="tel:<?= cms_e(cms_tel($phone)) ?>">Call <?= cms_e($phone) ?></a>
                            <?php endif ?>
                            <?php if ($whatsapp !== ''): ?>
                                <a class="btn btn-success" href="<?= cms_e(cms_whatsapp_url($whatsapp)) ?>" target="_blank" rel="noopener">WhatsApp us</a>
                            <?php endif ?>
                            <?php if ($email !== ''): ?>
                                <a class="btn btn-outline-secondary" href="mailto:<?= cms_e($email) ?>">Email us</a>
                            <?php endif ?>
                        </div>
                    </div>
                <?php endif ?>
            </div>
        </aside>
    </div>
</div>
