<?php /** Hero: full-width cover image with the title over it. @var array $post */ ?>
<header class="cms-hero d-flex align-items-end text-white">
    <?php if ($post['cover_image']): ?>
        <img src="<?= cms_e($post['cover_image']) ?>" alt="" class="cms-hero-img" fetchpriority="high">
    <?php endif ?>
    <div class="container cms-article cms-hero-content py-5">
        <p class="small mb-2 opacity-75">
            <a href="/blogs" class="text-reset">Blog</a> ·
            <time datetime="<?= cms_e($post['published_at']) ?>"><?= cms_e(cms_date($post['published_at'])) ?></time>
        </p>
        <h1 class="display-5 fw-bold"><?= cms_e($post['title']) ?></h1>
        <?php if ($post['excerpt']): ?>
            <p class="lead mb-0 opacity-75"><?= cms_e($post['excerpt']) ?></p>
        <?php endif ?>
    </div>
</header>

<article class="container cms-article py-5">
    <?php cms_render_blocks($post['blocks']) ?>
</article>
