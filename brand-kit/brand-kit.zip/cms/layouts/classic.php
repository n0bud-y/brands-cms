<?php /** Classic: cover image on top, then the content. @var array $post */ ?>
<article class="container cms-article py-5">
    <header class="mb-4">
        <p class="small text-muted mb-2">
            <a href="/blogs" class="text-reset">Blog</a> ·
            <time datetime="<?= cms_e($post['published_at']) ?>"><?= cms_e(cms_date($post['published_at'])) ?></time>
        </p>
        <h1 class="display-6 fw-bold"><?= cms_e($post['title']) ?></h1>
        <?php if ($post['excerpt']): ?>
            <p class="lead text-muted"><?= cms_e($post['excerpt']) ?></p>
        <?php endif ?>
    </header>

    <?php if ($post['cover_image']): ?>
        <img src="<?= cms_e($post['cover_image']) ?>" alt="<?= cms_e($post['title']) ?>" class="img-fluid rounded w-100 mb-5" fetchpriority="high">
    <?php endif ?>

    <?php cms_render_blocks($post['blocks']) ?>
</article>
