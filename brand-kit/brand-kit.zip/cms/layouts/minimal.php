<?php /** Minimal: text only, no cover image. @var array $post */ ?>
<article class="container cms-article cms-narrow py-5">
    <header class="mb-5 text-center">
        <p class="small text-muted mb-2">
            <time datetime="<?= cms_e($post['published_at']) ?>"><?= cms_e(cms_date($post['published_at'])) ?></time>
        </p>
        <h1 class="display-6 fw-bold"><?= cms_e($post['title']) ?></h1>
    </header>

    <?php cms_render_blocks($post['blocks']) ?>
</article>
