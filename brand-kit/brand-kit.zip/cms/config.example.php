<?php
// Copy this file to cms/config.php and fill it in.
// The dashboard's Brand page shows these values ready to paste (Brand -> "Connect the website").

return [
    'panel_url'    => 'https://panel.youragency.com', // the central panel, no trailing slash
    'site'         => 'brand-a',                      // this brand's slug in the panel
    'api_key'      => '',                             // shown once when the brand is created
    'cache_secret' => '',                             // lets the panel clear this site's cache
    'site_url'     => 'https://brand-a.com',          // this website, used for canonical URLs and the sitemap

    // Optional:
    // 'cache_ttl'      => 600,   // seconds a cached response stays fresh
    // 'posts_per_page' => 9,
    // 'kit_url'        => '/cms', // public URL of this cms/ folder
    // Point these at partials that use your website's real header and footer:
    // 'header'         => __DIR__ . '/partials/header.php',
    // 'footer'         => __DIR__ . '/partials/footer.php',
];
