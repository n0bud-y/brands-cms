<?php
// Page footer for the blog pages. Replace with your website's real footer markup;
// every value below comes from the brand's Settings page in the dashboard.

$socials = array_filter([
    'Facebook' => setting_raw('facebook'),
    'Instagram' => setting_raw('instagram'),
    'LinkedIn' => setting_raw('linkedin'),
    'X' => setting_raw('twitter'),
    'YouTube' => setting_raw('youtube'),
    'TikTok' => setting_raw('tiktok'),
]);
?>
</main>
<footer class="border-top bg-light mt-5 py-5">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-6">
                <p class="fw-semibold mb-2"><?= cms_e(cms_site_name()) ?></p>
<?php if (setting_raw('address') !== ''): ?>
                <p class="text-muted mb-2"><?= nl2br(setting('address')) ?></p>
<?php endif ?>
                <ul class="list-unstyled mb-0">
<?php if (setting_raw('email') !== ''): ?>
                    <li><a href="mailto:<?= setting('email') ?>"><?= setting('email') ?></a></li>
<?php endif ?>
<?php if (setting_raw('phone') !== ''): ?>
                    <li><a href="tel:<?= cms_e(cms_tel(setting_raw('phone'))) ?>"><?= setting('phone') ?></a></li>
<?php endif ?>
<?php if (setting_raw('whatsapp') !== ''): ?>
                    <li><a href="<?= cms_e(cms_whatsapp_url(setting_raw('whatsapp'))) ?>" rel="noopener" target="_blank">WhatsApp</a></li>
<?php endif ?>
                </ul>
            </div>
<?php if ($socials): ?>
            <div class="col-md-6 text-md-end">
<?php foreach ($socials as $label => $url): ?>
                <a class="me-3 me-md-0 ms-md-3" href="<?= cms_e($url) ?>" rel="noopener" target="_blank"><?= cms_e($label) ?></a>
<?php endforeach ?>
            </div>
<?php endif ?>
        </div>
<?php if (setting_raw('footer_text') !== ''): ?>
        <p class="text-muted small mt-4 mb-0"><?= setting('footer_text') ?></p>
<?php endif ?>
    </div>
</footer>
</body>
</html>
