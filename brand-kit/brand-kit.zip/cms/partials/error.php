<?php
/**
 * 404 / 503 page. Rendered by cms_error_page().
 *
 * @var int    $status
 * @var string $title
 * @var string $message
 */
cms_header(['title' => $title, 'robots' => 'noindex']);
?>
<div class="container py-5 text-center">
    <p class="display-1 fw-bold text-muted"><?= (int) $status ?></p>
    <h1 class="h3"><?= cms_e($title) ?></h1>
    <p class="text-muted"><?= cms_e($message) ?></p>
    <a class="btn btn-primary mt-3" href="/blogs">Back to the blog</a>
</div>
<?php cms_footer();
