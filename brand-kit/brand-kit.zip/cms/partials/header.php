<?php
/**
 * Page header for the blog pages. Replace the <body> part with your website's real
 * header markup; keep the <head> tags, they carry each post's SEO meta.
 *
 * @var array $meta  see cms_header()
 */
$siteName = cms_site_name();
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= cms_e($meta['title'] ?: $siteName) ?></title>
<?php if ($meta['description'] !== ''): ?>
    <meta name="description" content="<?= cms_e($meta['description']) ?>">
<?php endif ?>
<?php if ($meta['robots'] !== ''): ?>
    <meta name="robots" content="<?= cms_e($meta['robots']) ?>">
<?php endif ?>
    <link rel="canonical" href="<?= cms_e($meta['url']) ?>">
<?php if ($meta['prev']): ?>
    <link rel="prev" href="<?= cms_e($meta['prev']) ?>">
<?php endif ?>
<?php if ($meta['next']): ?>
    <link rel="next" href="<?= cms_e($meta['next']) ?>">
<?php endif ?>
    <meta property="og:type" content="<?= cms_e($meta['type']) ?>">
    <meta property="og:site_name" content="<?= cms_e($siteName) ?>">
    <meta property="og:title" content="<?= cms_e($meta['title']) ?>">
    <meta property="og:url" content="<?= cms_e($meta['url']) ?>">
<?php if ($meta['description'] !== ''): ?>
    <meta property="og:description" content="<?= cms_e($meta['description']) ?>">
<?php endif ?>
<?php if ($meta['image'] !== ''): ?>
    <meta property="og:image" content="<?= cms_e($meta['image']) ?>">
<?php endif ?>
    <meta name="twitter:card" content="<?= $meta['image'] !== '' ? 'summary_large_image' : 'summary' ?>">
<?php if (setting_raw('favicon') !== ''): ?>
    <link rel="icon" href="<?= setting('favicon') ?>">
<?php endif ?>
    <?= cms_schema_tags($meta) ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= cms_e(cms_asset('blog.css')) ?>">
</head>
<body>
<header class="border-bottom bg-white">
    <nav class="navbar container">
        <a class="navbar-brand d-flex align-items-center gap-2" href="/">
<?php if (setting_raw('logo') !== ''): ?>
            <img src="<?= setting('logo') ?>" alt="<?= cms_e($siteName) ?>" height="36">
<?php else: ?>
            <span class="fw-semibold"><?= cms_e($siteName) ?></span>
<?php endif ?>
        </a>
        <div class="d-flex align-items-center gap-3">
            <a class="nav-link" href="/blogs">Blog</a>
<?php if (setting_raw('phone') !== ''): ?>
            <a class="nav-link d-none d-sm-inline" href="tel:<?= cms_e(cms_tel(setting_raw('phone'))) ?>"><?= setting('phone') ?></a>
<?php endif ?>
        </div>
    </nav>
</header>
<main>
