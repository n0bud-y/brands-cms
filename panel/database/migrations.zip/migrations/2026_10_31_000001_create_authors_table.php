<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /** Writer profiles per brand, shown in a box under each post; plus each post's writer and category. */
    public function up(): void
    {
        Schema::create('authors', function (Blueprint $table) {
            $table->id();
            $table->foreignId('site_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('role')->nullable();
            $table->string('photo', 2048)->nullable();
            $table->text('bio')->nullable();
            $table->boolean('is_default')->default(false);
            $table->timestamps();
        });

        Schema::table('posts', function (Blueprint $table) {
            $table->foreignId('author_id')->nullable()->after('layout')->constrained()->nullOnDelete();
            $table->boolean('show_author')->default(true)->after('author_id');
            $table->string('category', 80)->nullable()->after('show_author');
        });
    }

    public function down(): void
    {
        Schema::table('posts', function (Blueprint $table) {
            $table->dropConstrainedForeignId('author_id');
            $table->dropColumn(['show_author', 'category']);
        });
        Schema::dropIfExists('authors');
    }
};
