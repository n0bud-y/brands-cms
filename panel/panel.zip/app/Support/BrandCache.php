<?php

namespace App\Support;

use App\Models\Site;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Throwable;

use function Illuminate\Support\defer;

/**
 * Tells a brand site to drop its cached API responses so edits show up at once.
 * Failure is never fatal: the brand cache simply expires on its own TTL.
 */
final class BrandCache
{
    public static function purge(Site $site): bool
    {
        try {
            $ok = Http::connectTimeout(2)
                ->timeout(4)
                ->withHeaders(['X-Cache-Secret' => $site->cache_secret])
                ->post($site->cacheClearUrl())
                ->successful();
        } catch (Throwable $e) {
            $ok = false;
        }

        if (! $ok) {
            Log::warning("Brand cache purge failed for [{$site->slug}] at {$site->cacheClearUrl()}");
        }

        return $ok;
    }

    /** Purge after the response has been sent, so the admin never waits on a brand site. */
    public static function purgeLater(Site $site): void
    {
        defer(fn () => self::purge($site), "brand-cache-{$site->id}");
    }
}
