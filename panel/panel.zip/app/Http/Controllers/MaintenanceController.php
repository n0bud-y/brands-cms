<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Artisan;
use Throwable;

/**
 * Admin-only links for hosting without a terminal: open the URL, read the result.
 * Each task is safe to run more than once.
 */
class MaintenanceController extends Controller
{
    private const TASKS = [
        'storage-link' => ['storage:link', [], 'Make uploaded images public (public/storage → storage/app/public)'],
        'migrate' => ['migrate', ['--force' => true], 'Apply new database changes after uploading an update'],
        'optimize' => ['optimize', [], 'Rebuild the config/route/view caches after an update or .env change'],
        'clear-cache' => ['optimize:clear', [], 'Clear every cache (use if a change to .env is not picked up)'],
    ];

    public function index()
    {
        $links = collect(self::TASKS)->map(fn ($task, $key) => '<li><a href="/maintenance/'.$key.'">/maintenance/'.$key.'</a> – '.e($task[2]).'</li>');

        return response('<!doctype html><meta charset="utf-8"><meta name="robots" content="noindex"><title>Maintenance</title>'
            .'<body style="font:16px/1.6 system-ui;max-width:720px;margin:40px auto;padding:0 16px">'
            .'<h1>Maintenance</h1><ul>'.$links->implode('').'</ul><p><a href="/">← Back to the panel</a></p>');
    }

    public function run(string $task)
    {
        abort_unless(isset(self::TASKS[$task]), 404);
        [$command, $options] = self::TASKS[$task];

        try {
            $code = Artisan::call($command, $options);
            $output = trim(Artisan::output()) ?: 'Done.';
        } catch (Throwable $e) {
            $code = 1;
            $output = $e->getMessage();
        }

        // storage:link reports success even when the link already exists; say so plainly.
        $link = public_path('storage');
        if ($task === 'storage-link' && is_link($link)) {
            $output .= "\n\npublic/storage is linked to ".readlink($link);
        } elseif ($task === 'storage-link' && is_dir($link)) {
            $code = 1;
            $output .= "\n\npublic/storage is a normal folder, not a link (an upload often copies the link as a folder). "
                .'Move any files inside it to storage/app/public, delete public/storage, then open this link again.';
        } elseif ($task === 'storage-link') {
            $code = 1;
            $output .= "\n\nThe link could not be made. This host may block symlinks (ask support to enable symlink(), "
                .'or to create public/storage as a link to storage/app/public).';
        }

        return response(($code === 0 ? "OK: {$command}" : "FAILED: {$command}")."\n\n{$output}\n", $code === 0 ? 200 : 500)
            ->header('Content-Type', 'text/plain; charset=utf-8');
    }
}
